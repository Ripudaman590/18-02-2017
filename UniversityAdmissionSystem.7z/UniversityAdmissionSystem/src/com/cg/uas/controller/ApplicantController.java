package com.cg.uas.controller;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;



import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.uas.bean.Application;
import com.cg.uas.exception.ApplicationException;
import com.cg.uas.service.ApplicantServiceImpl;
import com.cg.uas.service.IApplicantService;

@WebServlet("/ApplicantController")
public class ApplicantController extends HttpServlet 
{
private IApplicantService appService = null;
	
	//init block
	@Override
	public void init() throws ServletException {
		appService = new ApplicantServiceImpl();
	}
	
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String action = request.getParameter("action");
		Application app = null;
		switch (action)
		{
		case "register":
			
					int applicationid  =Integer.parseInt(request.getParameter("applicationid"));
					String fullname = request.getParameter("fullname");
					String dob1 = request.getParameter("dob");
					String highestqual = request.getParameter("highestqual");
					Double marks = Double.parseDouble(request.getParameter("marks"));
					String goals = request.getParameter("goals");
					String email = request.getParameter("email");
					String scheduledProgramId = request.getParameter("scheduledProgramId");
					String status = request.getParameter("status");
					String doi1 = request.getParameter("doi");
			
					
					SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
				
			try {
				Date dob = formatter.parse(dob1);
				java.sql.Date dateSql = new java.sql.Date(dob.getTime());

				Date doi = formatter.parse(doi1 );
				java.sql.Date dateSql1 = new java.sql.Date(doi.getTime());


				app = new Application();

				app.setApplicationId(applicationid);
				app.setFullName(fullname);
				app.setDob(dateSql);
				app.setHighestQual(highestqual);
				app.setMarks(marks);
				app.setGoals(goals);
				app.setEmailId(email);
				app.setScheduledProgramId(scheduledProgramId);
				app.setStatus(status);
				app.setDoi(dateSql1);
				



appService.addApplicant(app);
			} catch (ParseException | ApplicationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
				request.getSession().setAttribute("app", app);
			
			RequestDispatcher rd = request.getRequestDispatcher("ApplicationHome.jsp");//dispatching to next page
			rd.forward(request, response);
			
			return;

		default:
			break;
		}
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doGet(request, response);
	}

}
