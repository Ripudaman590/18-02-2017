package com.cg.uas.service;

import com.cg.uas.bean.Application;
import com.cg.uas.exception.ApplicationException;

public interface IApplicantService 
{


	public int addApplicant(Application app) throws ApplicationException;

	public int generateAppId() throws ApplicationException;
	
}
